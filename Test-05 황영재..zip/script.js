const btn = document.querySelector("button");
const log = document.querySelector("#id");

let xhr = new XMLHttpRequest();
xhr.open("GET", "https://jsonplaceholder.typicode.com/comments");
xhr.send();


btn.addEventListener("click", () => {
  
})
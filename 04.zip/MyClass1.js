export const p1Tag = document.createElement('p')
pTag.innerHTML = `오늘은 기분좋은 날이에요`
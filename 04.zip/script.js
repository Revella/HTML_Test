import p1Tag from "./MyClass1.js";
import p2Tag from "./MyClass2.js";

const log = document.querySelector(".log");

log.appendChild(p1Tag);
log.appendChild(p2Tag);
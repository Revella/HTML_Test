export const p2Tag = document.createElement("p")

p2Tag.innerHTML = `항상 그렇게 늘 파이팅 입니다.`
setInterval(()=>{
  const today = new Date();
  const hour = today.getHours() ;
  const min = today.getMinutes();
  const sec = today.getSeconds();

  let degHour = hour * (360 / 12) + min * (360 / 12 / 60);
  let degMin = min * (360 / 60);
  let degSec = sec * (360 / 60);

  const elementHours = document.querySelector(".lineHour");
  const elementMin = document.querySelector(".lineMin");
  const elementSec = document.querySelector(".lineSec");

  elementHours.style.transform = `rotate(${degHour}deg)`;
  elementMin.style.transform = `rotate(${degMin}deg)`;
  elementSec.style.transform = `rotate(${degSec}deg)`;
},1000);
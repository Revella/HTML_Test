/* Users */ 
const comBtn = document.querySelector("#complet");

const email = document.querySelector("#email").value;
const userName = document.querySelector("#name").value;
const pw = document.querySelector("#pw").value;
const pwCheck = document.querySelector("#pwCheck").value;
const errors = document.querySelectorAll(".errors");

if(email && userName && pw && pwCheck) {
  document.querySelector("#randoms").disabled = false;
}

/*Phone Number*/ 
const checked1 = function() {
  let num1 = document.querySelector("#phonNum1").value;

  if( num1.length === 3) {
    document.querySelector("#phonNum2").focus();
  }
}

const checked2 = function() {
  let num2 = document.querySelector("#phonNum2").value;

  if( num2.length === 4) {
    document.querySelector("#phonNum3").focus();
  }
}
const checked3 = function() {
  let num1 = document.querySelector("#phonNum1").value;
  let num2 = document.querySelector("#phonNum2").value;
  let num3 = document.querySelector("#phonNum3").value;

  if( num1 && num2 && num3) {
    document.querySelector("#complet").disabled = false;
  } else {
    document.querySelector("#complet").disabled = true;
  }
}

  /* Number */
  const isStarted = false;
  const randomNum = document.querySelector(".randomNum");
  const checkNum = document.querySelector(".comNum");
  const checkBtn = document.querySelector("#chekNum");


  checkBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if(isStarted === false) {
      isStarted = True;

      let random = String(Math.floor(Math.random() * 1000000)).padStart(6,"0");

      randomNum.innerText = random;
    }

    let time = 180;

    setInterval(function() {
      if(time >= 0) {
        let min = Math.floor(time / 60);
        let sec = String((time % 60).padStart(2,"0"));
        document.querySelector("#timer").innerText = `${min} : ${sec}`;
        time = time - 1;
      } else {
        document.querySelector(".comNum").disabled = true;
        isStarted = false;
        clearInterval();
      }
    }, 1000);
  })
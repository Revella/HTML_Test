const input = document.querySelector("input");
const saveBtn = document.querySelector(".btnSave");
const readBtn = document.querySelector(".btnRead");

saveBtn.addEventListener("click", save);

function save() {
  let inputValue = input.value;

  JSON.parse(localStorage.getItem(inputValue));
  localStorage.setItem(inputValue, JSON.stringify(inputValue));
}

readBtn.addEventListener("click", read);

function read() {
  window.localStorage.setItem(key);

  let keys = Object.key(window.localStorage);
  localStorage.getItem(key);
}

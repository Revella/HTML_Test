import React from 'react';
import logo from './logo.svg';
import './App.css';
import Form from './Component/Form';

function App() {

  return (
    <div className="App">
      <div className='container'>
        <div className="header">
          <h1>회원가입을 위해<br /> 정보를 입력해주세요.</h1>
        </div>
        <Form />
      </div>
    </div>
  );
}

export default App;

import React, { useEffect, useRef, useState } from 'react'

const Form = () => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [errorEmail, setErrorEmail] = useState("");
  const [errorName, setErrorName] = useState("");
  const [errorPw, setErrorPw] = useState("");

  const onChangeEmail = (e: any) => {
    setEmail(e.target.value);
  }
  const onChangeName = (e: any) => {
    setName(e.target.value);
  }
  const onChangePw = (e: any) => {
    setPw(e.target.value);
  }

  const handleSubmit = (e: any) => {
    if(email === "") {
      setErrorEmail('이메일이 입력되지 않았습니다.');
      e.target.focus();
    }
    if(name === "") {
      setErrorName('이름이 입력되지 않았습니다.');
      e.target.focus();
    }
    if(pw === "") {
      setErrorPw('비밀번호가 입력되지 않았습니다.');
      e.target.focus();
    }
    if(email !== "" && name !== "" && pw !== "") {
      alert(`어서오세요`);
    }
  }

  return (
    <div>
      <div className="form-email">
        <label>*이메일</label>
        <input onChange={onChangeEmail} value={email} type="text" />
        <div className='error'>{errorEmail}</div>
      </div>
      <div className='form-name'>
        <label>*이름</label>
        <input onChange={onChangeName} value={name} type="text" />
        <div className='error'>{errorName}</div>
      </div>
      <div className="form-pw">
        <label>*비밀번호</label>
        <input onChange={onChangePw} value={pw} type="password" />
        <div className='error'>{errorPw}</div>
      </div>
      <div className='form-gender'>
        <label><input type="radio" name='gender' /> 여성</label>
        <label><input type="radio" name='gender' /> 남성</label>
      </div>
      <div className='check'>
        <label><input type="checkbox" />이용약관 개인정보 수집 및 이용 이메일 활용 선택에 모두 동의 합니다.</label>
      </div>
      <div className='bar'></div>
      <div className='submit'>
        <button onClick={handleSubmit}>가입하기</button>
      </div>
    </div>
  )
}

export default Form
export const readFile = (filename: string): Promise<string> => {
  return new Promise<string>((resolve: (value: string)=> void, reject: (err: Error)=> void) => {
    readFile(filename,(err: Error, buffer: Buffer) => {
      if(err) rejcet(err)
      else resolve(buffer.toString());
    })
  })
}
// 로컬스토리지에 저장, 삭제, 전체삭제

const saveBtn = document.querySelector(".btnSave");
const remove = document.querySelector(".btnRemove");
const allRemove = document.querySelector(".btnClear");
const input = document.querySelector("input");

saveBtn.addEventListener("click", localSave);

function localSave() {
  let inputValue = input.value;

  JSON.parse(localStorage.getItem(inputValue));
  localStorage.setItem(inputValue, JSON.stringify(inputValue));
}

remove.addEventListener("click",removeLocal);

function removeLocal() {
  const localStorage = window.localStorage.getItem(localSave);
  for(let i = 0; i < localStorage; i ++){
    window.localStorage.removeItem(localStorage);
  }
}

allRemove.addEventListener("click", () => {
  window.localStorage.clear();
})